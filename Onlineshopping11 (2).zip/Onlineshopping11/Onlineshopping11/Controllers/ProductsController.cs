﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OnlineShopping11.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static Onlineshopping11.Models.ProductDBContext;

namespace Onlineshopping11.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ProductDbContext _context;

        public int ProductId { get; private set; }

        public ProductsController(ProductDbContext context)
        {
            _context = context;
        }


        [HttpGet]
        public async Task<ActionResult<IEnumerable<Products>>> GetProducts()
        {
            return await _context.Products.ToListAsync();
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<Products>> GetProduct(int id)
        {
            var Product = await _context.Products.FindAsync(id);

            if (Product == null)
            {
                return StatusCode(404);
            }

            return Product;
        }


        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProducts(int id, Products products)
        {
            if (id != ProductId)
            {
                return StatusCode(400);
            }

            _context.Entry(products).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductExists(id))
                {
                    return StatusCode(404);
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(204);
        }


        [HttpPost]
        public async Task<ActionResult<Products>> PostProducts(Products product)
        {
           
                _context.Add(product);
                await _context.SaveChangesAsync();
                return CreatedAtAction("GetProducts", new { id = product.Id }, product);
            
            
        }




        [HttpDelete("{id}")]
        public async Task<ActionResult<Products>> DeleteProducts(int id, ProductDbContext _context)
        {
            var products = await _context.Products.FindAsync(id);
            if (products == null)
            {
                return StatusCode(404);
            }

            _context.Products.Remove(products);
            await _context.SaveChangesAsync();

            return products;
        }

        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.Id == id);
        }
    }
}



